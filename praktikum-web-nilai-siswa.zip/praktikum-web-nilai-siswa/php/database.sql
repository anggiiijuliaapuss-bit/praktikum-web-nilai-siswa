-- ============================================================
--  SiNilai — Schema Database MySQL
--  Jalankan file ini di phpMyAdmin atau MySQL CLI
-- ============================================================

CREATE DATABASE IF NOT EXISTS db_sinilai
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE db_sinilai;

-- ── Tabel Admin ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tb_admin (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  username   VARCHAR(50)  NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
  nama_lengkap VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Password default: admin123 (bcrypt hash)
INSERT INTO tb_admin (username, password, nama_lengkap) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator'),
('guru',  '$2y$10$TKh8H1.PefBBDlmUNNiQ6.LVnXxHFKy9oN3eS.LY.jwN/zS3hSqky', 'Guru Mapel');

-- ── Tabel Siswa ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tb_siswa (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  nis        VARCHAR(20)  NOT NULL UNIQUE COMMENT 'Nomor Induk Siswa',
  nama       VARCHAR(100) NOT NULL,
  kelas      VARCHAR(10)  NOT NULL,
  jenis_kelamin ENUM('L','P') DEFAULT 'L',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Tabel Mata Pelajaran ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS tb_mapel (
  id    INT AUTO_INCREMENT PRIMARY KEY,
  kode  VARCHAR(10)  NOT NULL UNIQUE,
  nama  VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

INSERT INTO tb_mapel (kode, nama) VALUES
('MTK','Matematika'),('BIND','Bahasa Indonesia'),('BING','Bahasa Inggris'),
('FIS','Fisika'),('KIM','Kimia'),('BIO','Biologi'),('SEJ','Sejarah'),('EKO','Ekonomi');

-- ── Tabel Nilai ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tb_nilai (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  siswa_id   INT NOT NULL,
  mapel_id   INT NOT NULL,
  tahun_ajaran VARCHAR(10) NOT NULL DEFAULT '2024/2025',
  semester   TINYINT     NOT NULL DEFAULT 1 COMMENT '1 atau 2',
  uh         DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'Ulangan Harian (30%)',
  uts        DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'Ujian Tengah Semester (30%)',
  uas        DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'Ujian Akhir Semester (40%)',
  nilai_akhir DECIMAL(5,2) GENERATED ALWAYS AS
              (ROUND(uh * 0.30 + uts * 0.30 + uas * 0.40, 2)) STORED,
  grade       CHAR(1) GENERATED ALWAYS AS (
                CASE
                  WHEN ROUND(uh*0.30+uts*0.30+uas*0.40,2) >= 90 THEN 'A'
                  WHEN ROUND(uh*0.30+uts*0.30+uas*0.40,2) >= 80 THEN 'B'
                  WHEN ROUND(uh*0.30+uts*0.30+uas*0.40,2) >= 70 THEN 'C'
                  ELSE 'D'
                END
              ) STORED,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (siswa_id) REFERENCES tb_siswa(id) ON DELETE CASCADE,
  FOREIGN KEY (mapel_id) REFERENCES tb_mapel(id),
  UNIQUE KEY uq_siswa_mapel (siswa_id, mapel_id, tahun_ajaran, semester)
) ENGINE=InnoDB;

-- ── Sample Data ───────────────────────────────────────────────
INSERT INTO tb_siswa (nis, nama, kelas) VALUES
('2024001','Andi Pratama','X-A'),('2024002','Budi Santoso','X-A'),
('2024003','Citra Dewi','X-B'),('2024004','Dina Rahma','XI-A'),
('2024005','Eko Purnomo','XI-B'),('2024006','Fitria Sari','XII-A');

INSERT INTO tb_nilai (siswa_id, mapel_id, uh, uts, uas) VALUES
(1,1,85,80,88),(2,1,70,65,72),(3,3,92,88,95),
(4,4,60,58,62),(5,5,78,82,80),(6,6,88,90,93);

-- ── View Laporan Nilai ─────────────────────────────────────────
CREATE OR REPLACE VIEW vw_nilai_lengkap AS
SELECT
  n.id,
  s.nis, s.nama AS nama_siswa, s.kelas,
  m.kode AS kode_mapel, m.nama AS mata_pelajaran,
  n.tahun_ajaran, n.semester,
  n.uh, n.uts, n.uas,
  n.nilai_akhir,
  n.grade,
  CASE WHEN n.nilai_akhir >= 75 THEN 'Lulus' ELSE 'Remedial' END AS status,
  n.updated_at
FROM tb_nilai n
JOIN tb_siswa s ON s.id = n.siswa_id
JOIN tb_mapel m ON m.id = n.mapel_id
ORDER BY s.kelas, s.nama, m.nama;
