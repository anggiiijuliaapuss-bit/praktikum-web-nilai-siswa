<?php
// ============================================================
//  SiNilai — login.php (PHP + MySQL version)
// ============================================================
session_start();

// Redirect jika sudah login
if (isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'config.php';

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $pdo->prepare("SELECT * FROM tb_admin WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin'] = [
                'id'       => $admin['id'],
                'username' => $admin['username'],
                'nama'     => $admin['nama_lengkap'],
            ];
            header('Location: index.php');
            exit;
        } else {
            $error = 'Username atau password salah!';
        }
    } else {
        $error = 'Harap isi username dan password!';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login — SiNilai</title>
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg:#0d1117; --surface:#161b22; --border:#30363d;
      --accent:#58a6ff; --accent2:#3fb950; --text:#e6edf3;
      --muted:#8b949e; --danger:#f85149; --radius:12px;
    }
    body {
      font-family:'DM Sans',sans-serif; background:var(--bg);
      color:var(--text); min-height:100vh;
      display:flex; align-items:center; justify-content:center; overflow:hidden;
    }
    body::before {
      content:''; position:fixed; inset:0;
      background-image: linear-gradient(rgba(88,166,255,.04) 1px,transparent 1px),
                        linear-gradient(90deg,rgba(88,166,255,.04) 1px,transparent 1px);
      background-size:40px 40px;
      animation:gridMove 20s linear infinite;
    }
    @keyframes gridMove { to { background-position:40px 40px; } }
    .card {
      position:relative; z-index:10;
      background:var(--surface); border:1px solid var(--border);
      border-radius:20px; padding:48px 44px; width:100%; max-width:420px;
      box-shadow:0 24px 80px rgba(0,0,0,.6);
      animation:slideUp .6s cubic-bezier(.22,1,.36,1);
    }
    @keyframes slideUp { from{opacity:0;transform:translateY(32px)} to{opacity:1;transform:translateY(0)} }
    .logo { display:flex; align-items:center; gap:10px; margin-bottom:32px; }
    .logo-icon {
      width:42px; height:42px;
      background:linear-gradient(135deg,var(--accent),var(--accent2));
      border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:20px;
    }
    .logo-text { font-family:'DM Serif Display',serif; font-size:1.6rem; letter-spacing:-.5px; }
    h2 { font-size:.85rem; color:var(--muted); font-weight:400; margin-bottom:28px; }
    label { display:block; font-size:.78rem; font-weight:600; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); margin-bottom:6px; }
    input {
      width:100%; padding:12px 16px; background:var(--bg); border:1px solid var(--border);
      border-radius:var(--radius); color:var(--text); font-family:'DM Sans',sans-serif;
      font-size:.95rem; transition:border-color .2s,box-shadow .2s; margin-bottom:18px;
    }
    input:focus { outline:none; border-color:var(--accent); box-shadow:0 0 0 3px rgba(88,166,255,.15); }
    .btn {
      width:100%; padding:13px;
      background:linear-gradient(135deg,var(--accent),#1f6feb);
      border:none; border-radius:var(--radius); color:#fff;
      font-family:'DM Sans',sans-serif; font-size:1rem; font-weight:600;
      cursor:pointer; transition:transform .15s,box-shadow .15s; margin-top:8px;
    }
    .btn:hover { transform:translateY(-1px); box-shadow:0 8px 24px rgba(88,166,255,.3); }
    .error {
      background:rgba(248,81,73,.12); border:1px solid rgba(248,81,73,.3);
      color:var(--danger); padding:10px 14px; border-radius:8px;
      font-size:.85rem; margin-bottom:16px;
    }
    .hint {
      margin-top:20px; font-size:.78rem; color:var(--muted); text-align:center;
      padding:10px; background:rgba(255,255,255,.03); border-radius:8px;
      border:1px dashed var(--border);
    }
    .hint code { color:var(--accent2); }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">
      <div class="logo-icon">📊</div>
      <span class="logo-text">SiNilai</span>
    </div>
    <h2>Sistem Informasi Nilai Siswa — Login Administrator</h2>

    <?php if ($error): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <label for="username">Username</label>
      <input type="text" id="username" name="username"
             value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
             placeholder="admin" autocomplete="username" required/>

      <label for="password">Password</label>
      <input type="password" id="password" name="password"
             placeholder="••••••••" autocomplete="current-password" required/>

      <button type="submit" class="btn">Masuk →</button>
    </form>

    <div class="hint">
      Demo: username <code>admin</code> / password <code>admin123</code>
    </div>
  </div>
</body>
</html>
