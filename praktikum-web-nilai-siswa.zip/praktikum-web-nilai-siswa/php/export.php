<?php
// ============================================================
//  SiNilai — export.php (Export ke CSV)
// ============================================================
session_start();
if (!isset($_SESSION['admin'])) { header('Location: login.php'); exit; }

require_once 'config.php';

$stmt = $pdo->query("SELECT * FROM tb_nilai_siswa ORDER BY kelas, nama");
$data = $stmt->fetchAll();

$filename = 'data_nilai_siswa_' . date('Ymd_His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$out = fopen('php://output', 'w');

// BOM untuk Excel agar utf-8 terbaca
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));

// Header kolom
fputcsv($out, ['No','NIS','Nama Siswa','Kelas','Mata Pelajaran','UH','UTS','UAS','Nilai Akhir','Grade','Status','Tanggal Input']);

// Isi data
foreach ($data as $i => $row) {
    fputcsv($out, [
        $i + 1,
        $row['nis'],
        $row['nama'],
        $row['kelas'],
        $row['mapel'],
        $row['uh'],
        $row['uts'],
        $row['uas'],
        $row['nilai_akhir'],
        $row['grade'],
        $row['nilai_akhir'] >= 75 ? 'Lulus' : 'Remedial',
        $row['created_at'],
    ]);
}

fclose($out);
exit;
