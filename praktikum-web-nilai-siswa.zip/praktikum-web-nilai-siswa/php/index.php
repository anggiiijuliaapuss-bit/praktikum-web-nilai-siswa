<?php
// ============================================================
//  SiNilai — index.php (Dashboard + CRUD)
// ============================================================
session_start();
if (!isset($_SESSION['admin'])) { header('Location: login.php'); exit; }

require_once 'config.php';

$admin = $_SESSION['admin'];

// ── PROSES CRUD ──────────────────────────────────────────────
$msg = $msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // TAMBAH / EDIT
    if ($action === 'save') {
        $id    = intval($_POST['id'] ?? 0);
        $nis   = trim($_POST['nis']);
        $nama  = trim($_POST['nama']);
        $kelas = trim($_POST['kelas']);
        $mapel = trim($_POST['mapel']);
        $uh    = floatval($_POST['uh']);
        $uts   = floatval($_POST['uts']);
        $uas   = floatval($_POST['uas']);

        if (!$nis || !$nama || !$kelas || !$mapel) {
            $msg = 'Harap isi semua field!'; $msgType = 'danger';
        } elseif ($uh < 0 || $uh > 100 || $uts < 0 || $uts > 100 || $uas < 0 || $uas > 100) {
            $msg = 'Nilai harus antara 0–100!'; $msgType = 'danger';
        } else {
            if ($id) {
                $stmt = $pdo->prepare(
                    "UPDATE tb_nilai_siswa SET nis=?,nama=?,kelas=?,mapel=?,uh=?,uts=?,uas=? WHERE id=?"
                );
                $stmt->execute([$nis,$nama,$kelas,$mapel,$uh,$uts,$uas,$id]);
                $msg = 'Data siswa berhasil diperbarui!'; $msgType = 'success';
            } else {
                $stmt = $pdo->prepare(
                    "INSERT INTO tb_nilai_siswa (nis,nama,kelas,mapel,uh,uts,uas) VALUES (?,?,?,?,?,?,?)"
                );
                $stmt->execute([$nis,$nama,$kelas,$mapel,$uh,$uts,$uas]);
                $msg = 'Data siswa berhasil ditambahkan!'; $msgType = 'success';
            }
        }
    }

    // HAPUS
    if ($action === 'delete') {
        $id = intval($_POST['id']);
        $pdo->prepare("DELETE FROM tb_nilai_siswa WHERE id=?")->execute([$id]);
        $msg = 'Data siswa berhasil dihapus!'; $msgType = 'warning';
    }
}

// ── BUAT TABEL JIKA BELUM ADA ────────────────────────────────
$pdo->exec("
    CREATE TABLE IF NOT EXISTS tb_nilai_siswa (
        id       INT AUTO_INCREMENT PRIMARY KEY,
        nis      VARCHAR(20)  NOT NULL,
        nama     VARCHAR(100) NOT NULL,
        kelas    VARCHAR(10)  NOT NULL,
        mapel    VARCHAR(50)  NOT NULL,
        uh       DECIMAL(5,2) NOT NULL DEFAULT 0,
        uts      DECIMAL(5,2) NOT NULL DEFAULT 0,
        uas      DECIMAL(5,2) NOT NULL DEFAULT 0,
        nilai_akhir DECIMAL(5,2) GENERATED ALWAYS AS
                  (ROUND(uh*0.30 + uts*0.30 + uas*0.40, 2)) STORED,
        grade    CHAR(1) GENERATED ALWAYS AS (
                  CASE
                    WHEN ROUND(uh*0.30+uts*0.30+uas*0.40,2)>=90 THEN 'A'
                    WHEN ROUND(uh*0.30+uts*0.30+uas*0.40,2)>=80 THEN 'B'
                    WHEN ROUND(uh*0.30+uts*0.30+uas*0.40,2)>=70 THEN 'C'
                    ELSE 'D'
                  END) STORED,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// ── AMBIL DATA ───────────────────────────────────────────────
$search = trim($_GET['q'] ?? '');
$fKelas = trim($_GET['kelas'] ?? '');
$fMapel = trim($_GET['mapel'] ?? '');

$where = []; $params = [];
if ($search) { $where[] = "(nama LIKE ? OR nis LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($fKelas)  { $where[] = "kelas=?"; $params[] = $fKelas; }
if ($fMapel)  { $where[] = "mapel=?"; $params[] = $fMapel; }

$whereStr = $where ? 'WHERE '.implode(' AND ', $where) : '';
$stmt = $pdo->prepare("SELECT * FROM tb_nilai_siswa $whereStr ORDER BY kelas,nama");
$stmt->execute($params);
$siswa = $stmt->fetchAll();

// Stats
$allStmt = $pdo->query("SELECT nilai_akhir FROM tb_nilai_siswa");
$allNilai = $allStmt->fetchAll(PDO::FETCH_COLUMN);
$totalSiswa = count($allNilai);
$avgNilai   = $totalSiswa ? round(array_sum($allNilai)/$totalSiswa,1) : 0;
$lulus      = count(array_filter($allNilai, fn($v) => $v >= 75));
$remedial   = $totalSiswa - $lulus;

// Edit mode
$editData = null;
if (isset($_GET['edit'])) {
    $s = $pdo->prepare("SELECT * FROM tb_nilai_siswa WHERE id=?");
    $s->execute([intval($_GET['edit'])]);
    $editData = $s->fetch();
}

// Daftar kelas & mapel
$KELAS = ['X-A','X-B','X-C','XI-A','XI-B','XI-C','XII-A','XII-B','XII-C'];
$MAPEL = ['Matematika','Bahasa Indonesia','Bahasa Inggris','Fisika','Kimia','Biologi','Sejarah','Ekonomi'];

function grade_cls($g) {
    return ['A'=>'badge-a','B'=>'badge-b','C'=>'badge-c','D'=>'badge-d'][$g] ?? 'badge-d';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>SiNilai — Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg:#0d1117; --surface:#161b22; --surface2:#1c2128; --border:#30363d;
      --accent:#58a6ff; --accent2:#3fb950; --warn:#e3b341; --danger:#f85149;
      --text:#e6edf3; --muted:#8b949e; --radius:12px;
    }
    body { font-family:'DM Sans',sans-serif; background:var(--bg); color:var(--text); min-height:100vh; }
    .sidebar {
      position:fixed; left:0; top:0; bottom:0; width:240px;
      background:var(--surface); border-right:1px solid var(--border);
      display:flex; flex-direction:column; z-index:100;
    }
    .sidebar-logo {
      padding:24px 20px 20px; border-bottom:1px solid var(--border);
      display:flex; align-items:center; gap:10px;
    }
    .logo-icon {
      width:36px; height:36px;
      background:linear-gradient(135deg,var(--accent),var(--accent2));
      border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:18px;
    }
    .logo-text { font-family:'DM Serif Display',serif; font-size:1.35rem; }
    nav { flex:1; padding:16px 12px; }
    nav a {
      display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:8px;
      text-decoration:none; color:var(--muted); font-size:.9rem; font-weight:500;
      transition:background .15s,color .15s; margin-bottom:2px;
    }
    nav a:hover { background:var(--surface2); color:var(--text); }
    nav a.active { background:rgba(88,166,255,.12); color:var(--accent); }
    nav .section-label {
      font-size:.7rem; font-weight:600; letter-spacing:.08em; text-transform:uppercase;
      color:var(--muted); padding:14px 12px 6px;
    }
    .sidebar-footer { padding:16px; border-top:1px solid var(--border); }
    .user-chip {
      display:flex; align-items:center; gap:10px; padding:10px 12px;
      background:var(--surface2); border-radius:8px;
    }
    .avatar {
      width:32px; height:32px; border-radius:50%;
      background:linear-gradient(135deg,var(--accent),var(--accent2));
      display:flex; align-items:center; justify-content:center;
      font-size:14px; font-weight:700; color:#fff;
    }
    .user-info { flex:1; }
    .user-name { font-size:.85rem; font-weight:600; }
    .user-role { font-size:.72rem; color:var(--muted); }
    .logout-btn { background:none; border:none; cursor:pointer; color:var(--muted); font-size:16px; }
    .logout-btn:hover { color:var(--danger); }
    .main { margin-left:240px; padding:32px; }
    .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:28px; }
    .page-title { font-family:'DM Serif Display',serif; font-size:1.8rem; }
    .page-sub { color:var(--muted); font-size:.85rem; margin-top:2px; }
    .btn {
      padding:10px 18px; border-radius:var(--radius); border:none; cursor:pointer;
      font-family:'DM Sans',sans-serif; font-size:.9rem; font-weight:600;
      transition:transform .15s,box-shadow .15s; display:inline-flex; align-items:center; gap:6px;
    }
    .btn:hover { transform:translateY(-1px); }
    .btn-primary { background:var(--accent); color:#0d1117; }
    .btn-primary:hover { box-shadow:0 6px 20px rgba(88,166,255,.35); }
    .btn-danger  { background:rgba(248,81,73,.15); color:var(--danger); border:1px solid rgba(248,81,73,.3); }
    .btn-warning { background:rgba(227,179,65,.15); color:var(--warn); border:1px solid rgba(227,179,65,.3); }
    .btn-sm { padding:6px 12px; font-size:.82rem; }
    .stats-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:28px; }
    .stat-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:20px; }
    .stat-label { font-size:.78rem; color:var(--muted); font-weight:600; letter-spacing:.05em; text-transform:uppercase; }
    .stat-value { font-size:2rem; font-weight:700; margin:6px 0 2px; }
    .stat-meta  { font-size:.78rem; color:var(--muted); }
    .stat-accent { color:var(--accent); } .stat-green { color:var(--accent2); }
    .stat-danger { color:var(--danger); }
    .alert {
      padding:12px 16px; border-radius:var(--radius); margin-bottom:20px;
      font-size:.9rem; font-weight:500;
    }
    .alert-success { background:rgba(63,185,80,.12); border:1px solid rgba(63,185,80,.3); color:var(--accent2); }
    .alert-danger  { background:rgba(248,81,73,.12); border:1px solid rgba(248,81,73,.3); color:var(--danger); }
    .alert-warning { background:rgba(227,179,65,.12); border:1px solid rgba(227,179,65,.3); color:var(--warn); }
    .card-panel { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); }
    .toolbar { display:flex; align-items:center; gap:12px; padding:14px 16px; margin-bottom:16px; }
    .toolbar { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); }
    .search-wrap { flex:1; position:relative; }
    .search-wrap input {
      width:100%; padding:9px 14px 9px 36px; background:var(--bg);
      border:1px solid var(--border); border-radius:8px; color:var(--text);
      font-family:'DM Sans',sans-serif; font-size:.9rem;
    }
    .search-wrap input:focus { outline:none; border-color:var(--accent); }
    .search-icon { position:absolute; left:11px; top:50%; transform:translateY(-50%); color:var(--muted); }
    select {
      padding:9px 14px; background:var(--bg); border:1px solid var(--border);
      border-radius:8px; color:var(--text); font-family:'DM Sans',sans-serif; font-size:.88rem;
    }
    table { width:100%; border-collapse:collapse; }
    thead th {
      background:var(--surface2); padding:13px 16px; text-align:left;
      font-size:.76rem; font-weight:600; letter-spacing:.06em; text-transform:uppercase;
      color:var(--muted); border-bottom:1px solid var(--border);
    }
    tbody tr { border-bottom:1px solid rgba(48,54,61,.5); transition:background .1s; }
    tbody tr:last-child { border-bottom:none; }
    tbody tr:hover { background:var(--surface2); }
    td { padding:13px 16px; font-size:.9rem; }
    .badge { display:inline-flex; align-items:center; padding:3px 10px; border-radius:20px; font-size:.75rem; font-weight:600; }
    .badge-a { background:rgba(63,185,80,.15); color:var(--accent2); }
    .badge-b { background:rgba(88,166,255,.15); color:var(--accent); }
    .badge-c { background:rgba(227,179,65,.15); color:var(--warn); }
    .badge-d { background:rgba(248,81,73,.15); color:var(--danger); }
    .actions { display:flex; gap:6px; }
    /* FORM PANEL */
    .form-panel { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:28px; margin-bottom:24px; }
    .form-panel-title { font-family:'DM Serif Display',serif; font-size:1.2rem; margin-bottom:20px; }
    .form-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
    .form-group { margin-bottom:0; }
    .form-label { display:block; font-size:.77rem; font-weight:600; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); margin-bottom:6px; }
    .form-control {
      width:100%; padding:11px 14px; background:var(--bg);
      border:1px solid var(--border); border-radius:8px; color:var(--text);
      font-family:'DM Sans',sans-serif; font-size:.93rem;
    }
    .form-control:focus { outline:none; border-color:var(--accent); box-shadow:0 0 0 3px rgba(88,166,255,.12); }
    .form-footer { display:flex; gap:10px; margin-top:20px; }
    .btn-ghost { background:transparent; border:1px solid var(--border); color:var(--muted); padding:10px 18px; border-radius:var(--radius); cursor:pointer; font-family:'DM Sans',sans-serif; font-size:.9rem; }
    .btn-ghost:hover { border-color:var(--text); color:var(--text); }
    .empty-state { text-align:center; padding:60px 20px; color:var(--muted); }
    .empty-state .empty-icon { font-size:3rem; margin-bottom:12px; }
  </style>
</head>
<body>

<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon">📊</div>
    <span class="logo-text">SiNilai</span>
  </div>
  <nav>
    <div class="section-label">Menu Utama</div>
    <a href="index.php" class="active">🏠 Dashboard</a>
    <a href="index.php?form=1">➕ Input Nilai</a>
    <div class="section-label">Laporan</div>
    <a href="export.php">📥 Export CSV</a>
    <a href="index.php" onclick="window.print();return false;">🖨️ Cetak</a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-chip">
      <div class="avatar"><?= strtoupper($admin['username'][0]) ?></div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($admin['nama']) ?></div>
        <div class="user-role">Administrator</div>
      </div>
      <a href="logout.php"><button class="logout-btn" title="Logout">⏻</button></a>
    </div>
  </div>
</aside>

<main class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Data Nilai Siswa</div>
      <div class="page-sub">Kelola data nilai siswa dengan mudah dan terstruktur</div>
    </div>
    <a href="index.php?form=1"><button class="btn btn-primary">➕ Tambah Siswa</button></a>
  </div>

  <!-- STATS -->
  <div class="stats-grid">
    <div class="stat-card"><div class="stat-label">Total Siswa</div><div class="stat-value stat-accent"><?= $totalSiswa ?></div><div class="stat-meta">terdaftar</div></div>
    <div class="stat-card"><div class="stat-label">Rata-rata Kelas</div><div class="stat-value stat-green"><?= $avgNilai ?: '-' ?></div><div class="stat-meta">nilai rata-rata</div></div>
    <div class="stat-card"><div class="stat-label">Lulus</div><div class="stat-value stat-green"><?= $lulus ?></div><div class="stat-meta">nilai &ge; 75</div></div>
    <div class="stat-card"><div class="stat-label">Remedial</div><div class="stat-value stat-danger"><?= $remedial ?></div><div class="stat-meta">nilai &lt; 75</div></div>
  </div>

  <?php if ($msg): ?>
    <div class="alert alert-<?= $msgType ?>">
      <?= $msgType === 'success' ? '✅' : ($msgType === 'warning' ? '⚠️' : '❌') ?>
      <?= htmlspecialchars($msg) ?>
    </div>
  <?php endif; ?>

  <!-- FORM INPUT / EDIT -->
  <?php if (isset($_GET['form']) || $editData): ?>
  <div class="form-panel">
    <div class="form-panel-title"><?= $editData ? 'Edit Data Siswa' : 'Tambah Data Siswa Baru' ?></div>
    <form method="POST" action="">
      <input type="hidden" name="action" value="save"/>
      <?php if ($editData): ?>
        <input type="hidden" name="id" value="<?= $editData['id'] ?>"/>
      <?php endif; ?>
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">NIS</label>
          <input class="form-control" name="nis" value="<?= htmlspecialchars($editData['nis'] ?? '') ?>" placeholder="2024001" required/>
        </div>
        <div class="form-group">
          <label class="form-label">Nama Siswa</label>
          <input class="form-control" name="nama" value="<?= htmlspecialchars($editData['nama'] ?? '') ?>" placeholder="Nama lengkap" required/>
        </div>
        <div class="form-group">
          <label class="form-label">Kelas</label>
          <select class="form-control" name="kelas" required>
            <option value="">— Pilih Kelas —</option>
            <?php foreach ($KELAS as $k): ?>
              <option value="<?= $k ?>" <?= ($editData['kelas']??'')===$k?'selected':'' ?>><?= $k ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Mata Pelajaran</label>
          <select class="form-control" name="mapel" required>
            <option value="">— Pilih Mapel —</option>
            <?php foreach ($MAPEL as $m): ?>
              <option value="<?= $m ?>" <?= ($editData['mapel']??'')===$m?'selected':'' ?>><?= $m ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Nilai UH (Ulangan Harian — 30%)</label>
          <input class="form-control" name="uh" type="number" min="0" max="100" step="0.01" value="<?= $editData['uh'] ?? '' ?>" placeholder="0–100" required/>
        </div>
        <div class="form-group">
          <label class="form-label">Nilai UTS (30%)</label>
          <input class="form-control" name="uts" type="number" min="0" max="100" step="0.01" value="<?= $editData['uts'] ?? '' ?>" placeholder="0–100" required/>
        </div>
        <div class="form-group">
          <label class="form-label">Nilai UAS (40%)</label>
          <input class="form-control" name="uas" type="number" min="0" max="100" step="0.01" value="<?= $editData['uas'] ?? '' ?>" placeholder="0–100" required/>
        </div>
      </div>
      <div class="form-footer">
        <a href="index.php"><button type="button" class="btn-ghost">Batal</button></a>
        <button type="submit" class="btn btn-primary">💾 Simpan Data</button>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <!-- FILTER / SEARCH -->
  <form method="GET" action="">
    <div class="toolbar">
      <div class="search-wrap">
        <span class="search-icon">🔍</span>
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Cari nama siswa atau NIS…"/>
      </div>
      <select name="kelas" onchange="this.form.submit()">
        <option value="">Semua Kelas</option>
        <?php foreach ($KELAS as $k): ?>
          <option value="<?=$k?>" <?=$fKelas===$k?'selected':''?>><?=$k?></option>
        <?php endforeach; ?>
      </select>
      <select name="mapel" onchange="this.form.submit()">
        <option value="">Semua Mapel</option>
        <?php foreach ($MAPEL as $m): ?>
          <option value="<?=$m?>" <?=$fMapel===$m?'selected':''?>><?=$m?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-primary btn-sm">Cari</button>
      <?php if ($search||$fKelas||$fMapel): ?>
        <a href="index.php"><button type="button" class="btn btn-sm" style="background:var(--surface2);color:var(--muted)">✕ Reset</button></a>
      <?php endif; ?>
    </div>
  </form>

  <!-- TABLE -->
  <div class="card-panel" style="overflow:hidden">
    <table>
      <thead>
        <tr>
          <th>#</th><th>NIS</th><th>Nama Siswa</th><th>Kelas</th>
          <th>Mata Pelajaran</th><th>UH</th><th>UTS</th><th>UAS</th>
          <th>Nilai Akhir</th><th>Grade</th><th>Status</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($siswa)): ?>
          <tr><td colspan="12">
            <div class="empty-state">
              <div class="empty-icon">📋</div>
              <p>Belum ada data siswa<?= $search||$fKelas||$fMapel ? ' yang sesuai filter' : '' ?>.</p>
            </div>
          </td></tr>
        <?php else: ?>
          <?php foreach ($siswa as $i => $s):
            $g = $s['grade']; ?>
          <tr>
            <td style="color:var(--muted)"><?= $i+1 ?></td>
            <td><code style="color:var(--accent2);font-size:.82rem"><?= htmlspecialchars($s['nis']) ?></code></td>
            <td><strong><?= htmlspecialchars($s['nama']) ?></strong></td>
            <td><?= $s['kelas'] ?></td>
            <td><?= $s['mapel'] ?></td>
            <td><?= $s['uh'] ?></td><td><?= $s['uts'] ?></td><td><?= $s['uas'] ?></td>
            <td><strong style="color:<?= $s['nilai_akhir']>=75?'var(--accent2)':'var(--danger)' ?>"><?= $s['nilai_akhir'] ?></strong></td>
            <td><span class="badge <?= grade_cls($g) ?>"><?= $g ?></span></td>
            <td>
              <?php if ($s['nilai_akhir'] >= 75): ?>
                <span class="badge badge-a">Lulus</span>
              <?php else: ?>
                <span class="badge badge-d">Remedial</span>
              <?php endif; ?>
            </td>
            <td>
              <div class="actions">
                <a href="?edit=<?= $s['id'] ?>"><button class="btn btn-warning btn-sm">✏️ Edit</button></a>
                <form method="POST" style="display:inline" onsubmit="return confirm('Hapus data ini?')">
                  <input type="hidden" name="action" value="delete"/>
                  <input type="hidden" name="id" value="<?= $s['id'] ?>"/>
                  <button class="btn btn-danger btn-sm" type="submit">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>
</body>
</html>
