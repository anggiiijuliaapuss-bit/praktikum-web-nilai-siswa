# 📊 SiNilai — Sistem Informasi Nilai Siswa

> **Tugas Praktikum Pemrograman Web**
> Aplikasi web untuk manajemen data nilai siswa berbasis HTML/JS dan PHP+MySQL dengan tampilan akademik premium.

---

## 👤 Identitas Mahasiswa

| Keterangan | Isi |
|---|---|
| **Nama** | [Anggi Julia Puspitasari] |
| **NIM** | [11240576] |
| **Prodi** | [Sistem Informasi] |
| **Mata Kuliah** | Pemrograman Web |
| **Dosen Pengampu** | [Asih Winantu, S.Kom., M.Cs.] |
| **Tahun Ajaran** | 2025/2026 |

---

## 📌 Deskripsi Proyek

**SiNilai** adalah aplikasi web sistem informasi nilai siswa yang memungkinkan administrator atau guru untuk mengelola data nilai secara digital. Aplikasi ini dikembangkan sebagai tugas praktikum pemrograman web dengan menerapkan konsep **CRUD** (Create, Read, Update, Delete) lengkap berbasis web.

Aplikasi tersedia dalam **2 versi**:
- **Versi HTML/JS** — dapat langsung dibuka di browser tanpa server, data disimpan di `localStorage`
- **Versi PHP + MySQL** — menggunakan server (XAMPP/Laragon) dengan database MySQL sungguhan

---

## ✅ Ketentuan Tugas yang Dipenuhi

| No | Ketentuan | Status |
|---|---|---|
| 1 | Halaman login administrator | ✅ Ada — `login.html` & `php/login.php` |
| 2 | Database + tabel untuk data siswa | ✅ Ada — `php/database.sql` |
| 3 | Fasilitas input data | ✅ Ada — form modal dengan validasi |
| 4 | Fasilitas lihat data | ✅ Ada — tabel rapor lengkap dengan filter & pencarian |
| 5 | Fasilitas hapus data | ✅ Ada — tombol hapus dengan konfirmasi |
| 6 | Fasilitas edit data | ✅ Ada — tombol edit dengan form pre-filled |
| 7 | Menggunakan template/framework CSS | ✅ Ada — custom CSS premium dengan Google Fonts |
| 8 | Laporan (capture DB, skrip, tampilan) | ✅ Ada — `laporan/Laporan_SiNilai_v3.docx` |

---

## 🗂️ Struktur File

```
sinilai-web/
│
├── login.html              ← Halaman login (versi HTML/JS)
├── index.html              ← Dashboard + CRUD (versi HTML/JS)
├── README.md               ← Dokumentasi proyek ini
│
├── php/                    ← Versi backend PHP + MySQL
│   ├── config.php          ← Konfigurasi koneksi database
│   ├── database.sql        ← Schema & data awal MySQL
│   ├── login.php           ← Halaman login server-side
│   ├── index.php           ← Dashboard + CRUD server-side
│   ├── logout.php          ← Proses logout & hapus session
│   └── export.php          ← Export data ke file CSV
│
└── laporan/
    └── Laporan_SiNilai.docx  ← Laporan lengkap praktikum
```

---

## 🚀 Cara Menjalankan

### Versi 1 — HTML/JS (Tanpa Server, Paling Mudah)

> Cocok untuk demo cepat. Tidak perlu instalasi apapun.

1. Download/clone repository ini
2. Buka file `login.html` langsung di browser (double-click)
3. Login menggunakan akun demo:

```
Username : admin
Password : admin123
```

4. Selesai! Langsung bisa digunakan.

---

### Versi 2 — PHP + MySQL (XAMPP)

> Cocok untuk pengumpulan tugas dengan database sungguhan.

**Prasyarat:** XAMPP / Laragon, PHP >= 7.4, MySQL >= 5.7

**1. Copy file ke htdocs**
```
Windows : C:\xampp\htdocs\sinilai\
Mac     : /Applications/XAMPP/htdocs/sinilai/
```

**2. Buat database**

Buka **phpMyAdmin** → tab **SQL** → paste isi `php/database.sql` → klik **Go**

**3. Akses aplikasi**
```
http://localhost/sinilai/login.php
```

---

## ✨ Fitur Lengkap

| Fitur | Keterangan |
|---|---|
| 🔐 **Login Admin** | Autentikasi dengan validasi, loading spinner, animasi error |
| ➕ **Input Nilai** | Form input NIS, nama, kelas, mapel, nilai UH/UTS/UAS |
| 📊 **Live Preview** | Nilai akhir & grade dihitung real-time saat mengisi form |
| 📋 **Lihat Data** | Tabel bergaya rapor formal dengan kop surat sekolah |
| 🔍 **Pencarian** | Cari siswa berdasarkan nama atau NIS |
| 🔽 **Filter** | Filter berdasarkan kelas dan mata pelajaran |
| ✏️ **Edit Data** | Ubah data, form terisi otomatis |
| 🗑️ **Hapus Data** | Hapus dengan dialog konfirmasi |
| 📈 **Statistik** | Total siswa, rata-rata nilai, jumlah lulus & remedial |
| 📥 **Export CSV** | Unduh seluruh data dalam format CSV |
| 🖨️ **Cetak** | Print halaman daftar nilai |
| ⏻ **Logout** | Keluar dan hapus sesi login |

---

## 🗄️ Struktur Database

**Nama database:** `db_sinilai` | **Tabel:** `tb_nilai_siswa`

| Kolom | Tipe | Keterangan |
|---|---|---|
| `id` | INT AUTO_INCREMENT | Primary key |
| `nis` | VARCHAR(20) | Nomor Induk Siswa |
| `nama` | VARCHAR(100) | Nama lengkap siswa |
| `kelas` | VARCHAR(10) | Kelas (X-A, XI-B, dst.) |
| `mapel` | VARCHAR(50) | Mata pelajaran |
| `uh` | DECIMAL(5,2) | Nilai Ulangan Harian (bobot 30%) |
| `uts` | DECIMAL(5,2) | Nilai Ujian Tengah Semester (bobot 30%) |
| `uas` | DECIMAL(5,2) | Nilai Ujian Akhir Semester (bobot 40%) |
| `nilai_akhir` | DECIMAL(5,2) | **Generated** — dihitung otomatis MySQL |
| `grade` | CHAR(1) | **Generated** — A/B/C/D otomatis |
| `created_at` | TIMESTAMP | Waktu data dimasukkan |

---

## 🧮 Rumus Penilaian

```
Nilai Akhir = (UH × 30%) + (UTS × 30%) + (UAS × 40%)
```

| Grade | Rentang | Status |
|---|---|---|
| **A** | ≥ 90 | ✅ Lulus — Sangat Baik |
| **B** | 80 – 89 | ✅ Lulus — Baik |
| **C** | 70 – 79 | ✅ Lulus — Cukup |
| **D** | < 70 | ❌ Remedial |

> Batas kelulusan: **Nilai Akhir ≥ 75**

---

## 🎨 Desain Tampilan

Tampilan dirancang dengan nuansa **akademik formal**:

- 🔤 **Font** — Playfair Display (serif, judul) + Source Sans 3 (body)
- 📜 **Kop Surat** — Header tabel bergaya kop surat resmi dengan identitas sekolah
- 🪬 **Motif Batik** — Strip ornamen merah-emas di atas tabel
- 💧 **Watermark** — Cap SiNilai semi-transparan di latar halaman
- 🎖️ **Grade Seal** — Badge grade berbentuk stempel bulat berwarna
- 🌑 **Dark Mode** — Tema gelap premium dengan aksen emas

---

## 🛠️ Teknologi

| Teknologi | Kegunaan |
|---|---|
| HTML5 | Struktur halaman |
| CSS3 | Styling, animasi, desain akademik |
| JavaScript ES6+ | Logika CRUD client-side |
| PHP 8.x | Backend & session handling |
| MySQL 8.x | Database relasional |
| PDO | Koneksi DB aman (anti SQL Injection) |
| Google Fonts | Playfair Display + Source Sans 3 |
| localStorage | Penyimpanan data versi HTML |

---

## 👤 Akun Default

| Username | Password | Role |
|---|---|---|
| `admin` | `admin123` | Administrator |
| `guru` | `guru2026` | Guru |

---

## 🔗 Demo Online

Jika GitHub Pages aktif, akses di:
```
https://[username].github.io/sinilai-web/login.html
```

---

## 📄 Laporan Praktikum

Laporan lengkap tersedia di `laporan/Laporan_SiNilai_v3.docx` berisi:

- **BAB I** — Pendahuluan & Latar Belakang
- **BAB II** — Landasan Teori & Teknologi
- **BAB III** — Perancangan Sistem & Database
- **BAB IV** — Implementasi, Screenshot & Pengujian Fungsional
- **BAB V** — Penjelasan Skrip Program
- **BAB VI** — Kesimpulan & Saran

---

*Tugas Praktikum Pemrograman Web — [STMIK ELRAHMA YOGYAKARTA] © 2025/2026*
